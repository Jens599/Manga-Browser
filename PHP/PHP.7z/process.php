<?php

$cover_name = $_FILES['cover']['name'];
